#include <iostream>
#include <map>
using namespace std;

int main(){
    int n;
    cin >> n;
    float k;
    cin >> k;
    float arr[n];
    for(int i=0;i<n;i++)
    {
        cin >> arr[i];
    }
    for(int i=0;i<n;i++)
    {
        arr[i]-=k;
    }
    int currsum=0;
    map<int, int> mp;
    int ans=0;
    for(int i=0;i<n;i++)
    {
        currsum+=arr[i];
        arr[i]=currsum;
        if(currsum==0)
        {
            ans++;
        }
        ans+=mp[currsum];
        mp[currsum]++;
    }
    cout << ans << endl;
}