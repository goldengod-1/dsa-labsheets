#include <iostream>
#include <queue>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        cin >> arr[i];
    }
    int currhappi=0;
    int max=0;
    priority_queue<int> pq;
    for(int i=0;i<n;i++)
    {
        if(arr[i]<0){
            pq.push((-1)*arr[i]);
        }
        currhappi+=arr[i];
        max++;
        if(currhappi<0)
        {
            currhappi+=pq.top();
            pq.pop();
            max--;
        }
    }
    cout << max << endl;
}