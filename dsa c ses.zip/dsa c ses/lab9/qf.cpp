#include <iostream>
#include <map>
using namespace std;

int main(){
    int n;
    int k;
    cin >> n >> k;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    int c=0;
    sort(arr, arr+n);
    int i=0;
    int j=n/2;
    while(j<n){
        if(arr[j]-arr[i]>=k){
            c++;
            i++;
            j++;
        }
        else{
            j++;
        }
    }
    cout << c << endl;
}