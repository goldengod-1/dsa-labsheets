#include <iostream>
#include <queue>
using namespace std;

int main(){
    int n;
    cin >> n;
    int arr1[n];
    int arr2[n];
    int sum1=0;
    for(int i=0;i<n;i++){
        cin>>arr1[i];
        sum1+=arr1[i];
    }
    int sum2=0;
    for(int i=0;i<n;i++){
        cin>>arr2[i];
        sum2+=arr2[i];
    }
    if(sum2>sum1){
        cout << -1 << endl;
    }
    else{
        int arr3[n];
        for(int i=0;i<n;i++){
            arr3[i]=arr1[i]-arr2[i];
        }
        int currsum=0;
        int ans=0;
        queue <int> q;
        for(int i=0;i<n;i++){
            currsum+=arr3[i];
            q.push(arr3[i]);
            if(currsum<0){
                currsum-=q.front();
                q.pop();
                ans=i;
            }
        }
        cout << ans << endl;
    }
}