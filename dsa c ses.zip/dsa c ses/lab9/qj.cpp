#include <iostream>
#include <map>
using namespace std;


int main(){
    int n;
    cin >> n;
    map<int, int> m;
    for(int i=0;i<n;i++){
        int a;
        int b;
        cin >> a >> b;
        m[a]++;
        m[b]--;
    }
    int maxi=0;
    int c=0;
    for(auto x: m){
        c+=x.second;
        maxi=max(maxi, c);
    }
    cout << maxi << endl;
}