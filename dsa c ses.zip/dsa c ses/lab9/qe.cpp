#include <iostream>
#include <map>
using namespace std;
int main(){
    int m;
    int k;
    int n;
    cin >> m >> k >> n;
    int nz1;
    cin >> nz1;
    map <pair<int, int>, int> m1;
    for(int i=0;i<nz1;i++){
        int x;
        int y;
        int e;
        cin >> x >> y >> e;
        m1[make_pair(x, y)]=e;
    }
    int nz2;
    cin >> nz2;
    map <pair<int, int>, int> m2;
    for(int i=0;i<nz2;i++){
        int x;
        int y;
        int e;
        cin >> x >> y >> e;
        m2[make_pair(x, y)]=e;
    }
    map <pair<int, int>, int> m3;
    for(auto x:m1){
        int k=x.first.second;
        for(auto y:m2){
            if(y.first.first==k)
            {
                m3[make_pair(x.first.first, y.first.second)]+=y.second*x.second;
            }
        }
    }
    int count=0;
    for(auto x:m3){
        count++;
    }
    cout << count << endl;
    for(auto x:m3){
        cout << x.first.first << " " << x.first.second << " " << x.second << endl;
    }
}