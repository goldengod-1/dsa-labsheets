#include <iostream>
#include <map>
using namespace std;

int main(){
    int n;
    int m;
    cin >> n >> m;
    int arr1[n];
    int arr2[m];
    for(int i=0;i<n;i++){
        cin>>arr1[i];
    }
    for(int i=0;i<m;i++){
        cin>>arr2[i];
    }
    sort(arr1, arr1+n);
    map<int, int>mp;
    for(int i=0;i<m;i++){
        mp[arr2[i]]=0;
    }
    for(int i=0;i<n;i++){
        if(mp.find(arr1[i])!=mp.end()){
            mp[arr1[i]]++;
        }
    }
    for(int i=0;i<m;i++){
        for(int j=0;j<mp[arr2[i]];j++){
            cout << arr2[i] << " ";
        }
    }
    for(int i=0;i<n;i++){
        if(mp.find(arr1[i])==mp.end()){
            cout << arr1[i] << " ";
        }
    }
    cout << endl;
}