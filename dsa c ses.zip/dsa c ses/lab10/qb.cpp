#include <iostream>
using namespace std;

int main(){
    int m;
    int n;
    cin >> m >> n;
    int mx[m][n];
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cin >> mx[i][j];
        }
    }
    int k;
    cin >> k;
    int i=0;
    int j=n-1;
    while(i<m&&j>=0){
        if(mx[i][j]==k){
            cout << "YES" << endl;
            return 0;
        }
        else{
            if(mx[i][j]<k){
                i++;
            }
            else{
                j--;
            }
        }
    }
    cout << "NO" << endl;
    return 0;
}