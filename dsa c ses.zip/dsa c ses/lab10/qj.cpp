#include <iostream>
#include <queue>
using namespace std;

int main(){
    int n;
    int k;
    cin>>n>>k;
    int arr[n][n];
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cin>>arr[i][j];
        }
    }
    priority_queue< pair<int, pair<int, int> >,vector<pair<int, pair<int, int> > >, greater<pair<int, pair<int, int> > > >minHeap;

    for(int i=0;i<n;i++){
        minHeap.push(make_pair(arr[0][i], make_pair(0, i)));
    }
    for(int i=0;i<k-1;i++){
        auto x=minHeap.top();
        minHeap.pop();
        minHeap.push(make_pair(arr[x.second.first+1][x.second.second], make_pair(x.second.first+1, x.second.second)));
    } 
    cout<<minHeap.top().first<<endl;
}
