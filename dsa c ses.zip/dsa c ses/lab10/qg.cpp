#include <iostream>
#include <deque>
using namespace std;

int main(){
    int n;
    int k;
    cin>>n>>k;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    deque<int> dq;
    for(int i=0;i<n;i++){
        if(!dq.empty()&&arr[dq.back()]<arr[i]){
            dq.pop_back();
        }
        dq.push_back(i);
        if(i>=k-1){
            if(dq.front()==i-k){
                dq.pop_front();
            }
            cout<<arr[dq.front()]<<" ";
        }
    }
    cout<<endl;
}