#include <iostream>
#include <map>
using namespace std;

int main(){
	int n1;
	int n2;
	cin>>n1;
	cin>>n2;
	map<int, int>mp1;
	map<int, int>mp2;
	int sum1=0;
	int sum2=0;
	for(int i=0;i<n1;i++){
		int x;
		cin>>x;
		mp1[x]++;
		sum1+=x;
	}
	for(int i=0;i<n2;i++){
		int x;
		cin>>x;
		mp2[x]++;
		sum2+=x;
	}
	if((sum1+sum2)%2){
		cout<<"no"<<endl;
		return 0;
	}
	else{
		int diff=abs(sum1-sum2)/2;
		if(mp1.size()<mp2.size()){
			for(auto x:mp1){
				if(mp2.find(x.first+diff)!=mp2.end()){
					cout<<"yes"<<endl;
					return 0;
				}
				else if(mp2.find(x.first-diff)!=mp2.end()){
					cout<<"yes"<<endl;
					return 0;
				}
				else{
					cout<<"no"<<endl;
					return 0;
				}
			}
		}
		else{
			for(auto x:mp2){
				if(mp1.find(x.first+diff)!=mp1.end()){
					cout<<"yes"<<endl;
					return 0;
				}
				else if(mp1.find(x.first-diff)!=mp1.end()){
					cout<<"yes"<<endl;
					return 0;
				}
				else{
					cout<<"no"<<endl;
					return 0;
				}
			}
		}
	}

}