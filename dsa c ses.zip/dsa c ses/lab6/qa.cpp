#include <iostream>
using namespace std;
class MinStack{
    public:
    int topstack;
    int astack[1000];
    int topmin;
    int amin[1000];

    MinStack(){
        topstack=-1;
        topmin=-1;
    }

    void push(int val){
        topstack++;
        astack[topstack]=val;
        topmin++;
        if (topmin == 0)
        {
            amin[topmin] = val;
        }
        else
        {
            amin[topmin]=min(amin[topmin-1], val);
        }
        return;
    }

    void pop(){
        topstack--;
        topmin--;
    }

    int top(){
        return astack[topstack];
    }

    int getMin(){
        return amin[topmin];
    }

};
int main(){
    MinStack ms;
    ms.push(20);
    ms.push(30);
    cout << ms.top()<<endl;
    cout << ms.topstack<<endl;
    cout<<ms.getMin()<<endl;
    return 0;
}




