#include <stdio.h>

void lex(int *arr, int n){
    int start=0;
    int end=0;
    int ans[n];
    for(int i=0;i<n;i++){
        if(i==0){
            ans[start]=arr[i];
        }
        else if(arr[i]<ans[start]){
            if(start==0){
                start=n;
            }
            start--;
            ans[start]=arr[i];
        }
        else{
            end++;
            ans[end]=arr[i];
        }
    }
    if(start==0){
        for(int i=0;i<n;i++){
            printf("%d ", ans[i]);
        }
    }
    else{
        for(int i=start;i<n;i++){
            printf("%d ", ans[i]);
        }
        for(int i=0;i<=end;i++){
            printf("%d ", ans[i]);
        }
    }
}

int main(){
    int n;
    scanf("%d", &n);
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d", &arr[i]);
    }
    lex(arr, n);
}