#include <iostream>
#include <stack>
using namespace std;
int main()
{   int n;
    cin >> n;

    int arr[n];

    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    int a[n];
    int b[n];
    int k=0;
    stack<int> prev_small;
    stack<int> next_small;

    for (int i = 0; i < n; i++)
    {
        while (!prev_small.empty() && arr[prev_small.top()] >= arr[i])
        {
            prev_small.pop();
        }
        if (prev_small.empty()){
            a[i]=-1;
        }
        else{
            a[i]=prev_small.top();
        }
        prev_small.push(i);
    }



    for(int i=n-1;i>=0;i--)
    {
        while(!next_small.empty() && arr[next_small.top()]>=arr[i])
        {
            next_small.pop();
        }
        if(next_small.empty()){
            b[i]=-1;
        }
        else{
            b[i]=next_small.top();
        }
        next_small.push(i);
    }

    for(int i=0;i<n;i++)
    {
        cout<<a[i]<<" "<<b[i]<<endl;
    }

    int maxans=0;
    for(int i=0;i<n;i++)
    {
        int cur=(b[i]-a[i]-1)*arr[i];
        maxans=max(cur,maxans);
    }
    cout<<maxans<<endl;
    return 0;
}