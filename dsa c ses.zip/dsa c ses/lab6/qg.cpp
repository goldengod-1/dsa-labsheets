#include<iostream>
#include<stack>

using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    stack<int> s;
    int i=0;
    while(i<n){
        if(i==0){
            cout<<"1 ";
            s.push(i);
            i++;
        }
        else{
            if(s.empty()){
                cout<<i+1<<" ";
                s.push(i);
                i++;
            }
            else if(arr[i]<arr[s.top()]){
                cout<<i-s.top()<<" ";
                s.push(i);
                i++;
            }
            else{
                s.pop();
            }
        }
    }
}
