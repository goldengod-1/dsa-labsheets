#include <iostream>
#include <vector>
using namespace std;
int main() {
    int k;
    cin>>k;
    for(int i=0;i<k;i++){
        int n;
        cin>>n;
        vector<int> arr(n);
        for(int j=0;j<n;j++){
            cin>>arr[j];
        }
        int c=0;
        for(int j=0;j<n-1;j++){
            if(arr[j+1]>arr[j]){
                c++;
            } 
        }
        if(c==0){
            cout<<0<<endl;
        }
        else{
            cout<<c-1<<endl;
        }
    }
    return 0;
}
