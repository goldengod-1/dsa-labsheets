#include <iostream>
#include <vector>
using namespace std;

int main(){
    
}