#include <iostream>
using namespace std;

int main(){
    int n;
    int k;
    cin >> n >> k;
    int arr[n];
    for(int i=0;i<n;i++){
        cin >> arr[i];
    }
    int i=0;
    int j=0;
    int lb=0;
    int ulb=0;
    if(arr[0]==1){
        lb++;
    }
    else{
        ulb++;
    }
    int ans=0;
    while(i<=j&&j<n){
        if(lb>k){
            if(arr[i]){
                lb--;
            }
            else{
                ulb--;
            }
            i++;
        }
        else{
            ans+=j-i+1;
            j++;
            if(arr[j]){
                lb++;
            }
            else{
                ulb++;
            }
        }
    }
    cout << ans << " ";
}