#include <iostream>
#include <map>
#include <set>
using namespace std;

int main(){
    int n;
    int k;
    cin >> n >> k;
    set<int> ws;
    map<int, int> ls;
    for(int i=0;i<n;i++){
        int w;
        int l;
        cin >> w >> l;
        if(ls[w]<=1){
            ws.insert(w);
        }
        if(ls[l]<1){
            ws.insert(l);
            ls[l]++;
        }
        else{
            ws.erase(l);
        }
    }
    for(auto x: ws){
        cout << x << " ";
    }
}