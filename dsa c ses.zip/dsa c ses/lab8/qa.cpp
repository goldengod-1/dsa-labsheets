#include <iostream>
#include <map>
#include <string>
#include <math.h>
using namespace std;

long long int hashp(string str){
    int arr[26];
    for(int i=0;i<26;i++){
        arr[i]=0;
    }
    int n=str.length();
    for(int i=0;i<n;i++){
        arr[str[i]-'a']++;
    }
    int k=0;
    for(int i=0;i<26;i++){
        if(arr[i]!=0){
            for(int j=0;j<arr[i];j++){
                str[k]=i+'a';
                k++;
            }
        }
    }
    long long int hash=0;
    for(int i=0;i<n;i++){
        hash+=pow(26,i)*(str[i]-'a');
    }
    return hash;
}

int main(){
    int n;
    int m;
    cin >> n >> m;
    map<long long int, int> mp;
    for(int i=0;i<n;i++){
        string str;
        cin >> str;
        if(mp.find(hashp(str))==mp.end()){
            mp[hashp(str)]=1;
        }
        else{
            mp[hashp(str)]++;
        }
    }
    int ans=0;
    for(auto x:mp){
        ans+=x.second*(x.second-1)/2;
    }
    cout << ans;
}
