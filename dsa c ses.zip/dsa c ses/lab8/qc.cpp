#include<iostream>
#include<map>
using namespace std;

int main(){
    int n;
    cin >> n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin >> arr[i];
    }
    int x;
    int y;
    cin >> x >> y;
    int mx[n];
    int my[n];
    for(int i=0;i<n;i++){
        mx[i]=arr[i]-x*i;
        my[i]=arr[i]-y*i;
    }
    map<int, int> mp;
    for(auto x: my){
        mp[x]++;
    }
    int ans=0;
    for(int i=0;i<n;i++){
        mp[my[i]]--;
        ans+=mp[mx[i]];
    }
    cout << ans;
}