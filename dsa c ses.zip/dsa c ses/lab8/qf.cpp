#include<iostream>
#include <map>
using namespace std;

int main(){
    int n;
    cin >> n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin >> arr[i];
    }
    map<int, int>mp;
    int cxor=0;
    int ans=0;
    for(int i=0;i<n;i++){
        cxor^=arr[i];
        if(cxor==0){
            ans++;
        }
        if(mp[cxor]>0){
            ans+=mp[cxor];
        }
        mp[cxor]++;
    }
    cout << ans << endl;
}