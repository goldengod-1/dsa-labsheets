#include <iostream>
#include <map>
#include <stack>
using namespace std;

int main(){
    int n;
    int m;
    int k;
    cin >> n >> m >> k;
    int arr[n];
    for(int i=0;i<n;i++){
        cin >> arr[i];
    }
    map<int, int> mp;
    for(int i=0;i<m;i++){
        mp[arr[i]]++;
        
    }
    stack<int>st;
    st.push(-1);

}