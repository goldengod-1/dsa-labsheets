#include <iostream>
#include <map>
#include <algorithm>
using namespace std;


pair< pair<int, int>, pair<int, int> > slopeAndc(int x, int y, int x1, int y1)
{
    if(x!=0)
    {
        int r=__gcd(x, y);
        x/=r;
        y/=r;
        int c=x*y1-y*x1;
        int cd=x;
        r=__gcd(c, cd);
        c/=r;
        cd/=r;
        return {{y,x},{c, cd} };
    }
    else
    {
        return {{0 ,0},{x1, 1} };
    }
}

int main()
{
    int n;
    cin >> n;
    pair<int, int> points[n];
    for(int i=0;i<n;i++)
    {
        int x;
        int y;
        cin >> x >> y;
        points[i]={x, y};
    }
    int ans=n*(n-1)*(n-2)/6;
    map <pair < pair<int, int>, pair<int, int> >, int> mp;
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            int X=points[j].first-points[i].first;
            int Y=points[j].second-points[i].second;
            mp[slopeAndc(X, Y, points[i].first, points[i].second)]++;
        }
    }
    int sub=0;
    for(auto x: mp)
    {
        //cout << x.first.first.first << " " << x.first.first.second << " " <<x.first.second.first <<" " << x.first.second.second << " " << x.second << endl;
        if(!x.second<3){
            int m=x.second;
            sub+=m*(m-1)*(m-2)/6;
        }
    }
    cout << ans - sub << endl;
}