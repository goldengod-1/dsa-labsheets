#include <iostream>
#include <map>
using namespace std;

int main()
{
    int n;
    int q;
    cin >> n >> q;
    map<int, int> mp;
    for(int i=0;i<q;i++){
        int qt;
        int k;
        cin >> qt >> k;
        if(qt==1)
        {
            if(mp.find(k)==mp.end())
            {
                mp[k]=1;
            }
            else
            {
                if(mp[k]==1)
                {
                mp.erase(k);
                }
            }
        }
        if(qt==2)
        {
            if(mp.lower_bound(k)==mp.end())
            {
                cout << -1 << endl;
            }
            else
            {
                cout << mp.lower_bound(k)->first << endl;
            }
        }
        if(qt==3)
        {
            auto x=mp.upper_bound(k);
            if(x==mp.begin()){
                cout << "-1" << endl;
            }
            else
            {
                x--;
                if(x==mp.end())
                {
                    cout << -1 << endl;
                }
                else
                {
                    cout << x->first << endl;
                }
            }
        }
    }
}