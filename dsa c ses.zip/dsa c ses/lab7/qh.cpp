#include<iostream>

using namespace std;

class treeNode{
    public:
    int data;
    treeNode *left;
    treeNode *right;

    treeNode(int val){
        this->data=val;
        this->left=NULL;
        this->right=NULL;
    }
};

treeNode *makeTree(treeNode* curr, int *arr, int n, int i){
    if(i>=n){
        return curr;
    }
    if(i<n && arr[i]!=-1){
    curr = new treeNode(arr[i]);
    curr->left=makeTree(curr->left, arr, n, 2*i+1);
    curr->right=makeTree(curr->right, arr, n, 2*i+2);}
    return curr;
}

void postOrder(treeNode* node){
    if(node == nullptr) return;
    postOrder(node->left);
    postOrder(node->right);
    cout << node->data << " ";
}

int main(){
    int n;
    int l;
    int r;
    cin >> n;
    cin >> l;
    cin >> r;
    int arr[n];
    for(int i=0;i<n;i++){
        cin >> arr[i];
    }
    treeNode *root =NULL;
    root = makeTree(root, arr, n, 0);
    while(root!=NULL&&root->data<l){
        root = root->right;
    }
    while(root!=NULL&&root->data>r){
        root = root->left;
    }
    treeNode *temp = root;
    while(temp->left!=NULL&&temp->left->data>=l){
        temp=temp->left;
    }
    while(temp!=NULL&&temp->left!=NULL&&temp->left->data<l){
        temp->left=temp->left->right;
    }
    temp = root;
    while(temp->right!=NULL&&temp->right->data<=r){
        temp=temp->right;
    }
    while(temp!=NULL&&temp->right!=NULL&&temp->right->data>r){
        temp->right=temp->right->left;
    }
    postOrder(root);
}