#include<iostream>

using namespace std;

class treeNode{
    public:
    int data;
    treeNode *left;
    treeNode *right;

    treeNode(int val){
        this->data=val;
        this->left=NULL;
        this->right=NULL;
    }
};

treeNode *makeTree(treeNode* curr, int *arr, int n, int i){
    if(i>=n){
        return curr;
    }
    if(i<n && arr[i]!=-1){
    curr = new treeNode(arr[i]);
    curr->left=makeTree(curr->left, arr, n, 2*i+1);
    curr->right=makeTree(curr->right, arr, n, 2*i+2);}
    return curr;
}

int kthLargest(treeNode* root, int *k){
    if(root == NULL){
        return -1;
    }
    int right=kthLargest(root->right, k);
    if(*k==0){
        return right;
    }
    (*k)--;
    if(*k==0){
        return root->data;
    }
    return kthLargest(root->left, k);
    
}

int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    int k;
    cin>>k;
    int *x=&k;
    treeNode *root = makeTree(root, arr, n, 0);
    int ans=kthLargest(root, x);
    cout<<ans;
}