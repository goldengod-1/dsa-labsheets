#include<iostream>

using namespace std;

class treeNode{
    public:
    int data;
    treeNode *left;
    treeNode *right;

    treeNode(int val){
        this->data=val;
        this->left=NULL;
        this->right=NULL;
    }
};

treeNode *makeTree(treeNode* curr, int *arr, int n, int i){
    if(i>=n){
        return curr;
    }
    if(i<n && arr[i]!=-1){
    curr = new treeNode(arr[i]);
    curr->left=makeTree(curr->left, arr, n, 2*i+1);
    curr->right=makeTree(curr->right, arr, n, 2*i+2);}
    return curr;
}

void bst_to_gst(treeNode* root, int* tracker){
    // First we go to the right sub tree nodes
    if(root->right != NULL) bst_to_gst(root->right, tracker);
    // Then to the current node itself
    (*tracker) += root->data;
    // Then we assign the value to the node
    root->data = *tracker;
    // Then iterate through the left sub trees
    if(root->left != nullptr) bst_to_gst(root->left, tracker);
}

void makearr(int *arr, int l, treeNode *root, int i){
    if(i>l){
        return;
    }
    if(root==NULL){
        return;
    }
    else{
    arr[i]=root->data;
    makearr(arr, l, root->left, 2*i+1);
    makearr(arr, l, root->right, 2*i+2);
    return;}  
}

int main(){
    int n;
    cin>>n;
    int arr1[n];
    for(int i=0;i<n;i++){
        cin>>arr1[i];
    }
    treeNode *root=NULL;
    root = makeTree(root, arr1, n, 0);
    int tracker=0;
    bst_to_gst(root, &tracker);
    makearr(arr1, n, root, 0);
    for(int i=0;i<n;i++){
        cout<<arr1[i]<<" ";
    }
}
