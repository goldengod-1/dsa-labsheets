#include<iostream>
#include<queue>
#include<vector>
using namespace std;

int main(){
    int n;
    int k;
    cin >> n;
    cin >> k;
    vector<int> v;
    for(int i=0;i<n;i++){
        int x;
        cin>>x;
        v.push_back(x);
    }
    priority_queue<int> pq(v.begin(), v.end());
    int sum=0;
    for(int i=0;i<k;i++){
        int x;
        int y=pq.top();
        if(pq.top()%2){
            x=pq.top()/2+1;
        }
        else{
            x=pq.top()/2;
        }
        sum+=x;
        pq.pop();
        pq.push(y-x);
    }
    cout<<sum;
}