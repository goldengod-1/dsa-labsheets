#include <iostream>

using namespace std;

class treeNode{
    public:
    int data;
    treeNode *left;
    treeNode *right;

    treeNode(int val){
        this->data=val;
        this->left=NULL;
        this->right=NULL;
    }
};

treeNode *fillTree(treeNode *curr, int *arr, int n, int i){
    if(i>=n){
        return curr;
    }
    if(i<n && arr[i]!=-1){
    curr = new treeNode(arr[i]);
    curr->left=fillTree(curr->left, arr, n, 2*i+1);
    curr->right=fillTree(curr->right, arr, n, 2*i+2);}
    return curr;
}

void tatakae(treeNode *root, int k, int r, int *ans){
    if(r==k&&root==NULL){
        (*ans)++;
        return;
    }
    if(root==NULL){
        return;
    }
    if(root->left==NULL){
        r+=root->data;
        tatakae(root->right, k, r, ans);
    }
    else if(root->right==NULL){
        r+=root->data;
        tatakae(root->left, k, r, ans);
    }
    else{
    r+=root->data;
    tatakae(root->left, k, r, ans);
    tatakae(root->right, k, r, ans);
    }
}

void inorder(treeNode *root){
    if(root==NULL){
        return;
    }
    inorder(root->left);
    cout << root->data<<" ";
    inorder(root->right);
}

int main(){
    int n;
    cin >> n;
    int k;
    cin >> k;
    int arr[n];
    for(int i=0;i<n;i++){
        cin >> arr[i];
    }
    treeNode *root = NULL;
    root = fillTree(root,arr,n,0);
    //inorder(root);
    int x=0;
    int *ans=&x;
    tatakae(root, k, 0, ans);
    cout<< "\n";
    cout << *ans;

}