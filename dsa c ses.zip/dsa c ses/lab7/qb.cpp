#include<iostream>
#include <math.h>
using namespace std;

class treeNode{
    public:
    int data;
    treeNode *left;
    treeNode *right;

    treeNode(int val){
        this->data=val;
        this->left=NULL;
        this->right=NULL;
    }
};

int search(int* inorder, int n, int root){
    int x;
    for(int i=0;i<n;i++){
        if(inorder[i]==root){
            x=i;
            break;
        }
    }
    return x;
}

treeNode *makeTree(int *preorder, int *inorder, int leftin, int rightin, int n){
    static int prei=0;

    if(leftin>rightin){
        return NULL;
    }
    treeNode *curr = new treeNode(preorder[prei]);
    prei++;
    if(leftin==rightin){
        return curr;
    }
    int rootIndex=search(inorder, n, curr->data);

    curr->left=makeTree(preorder, inorder, leftin, rootIndex-1, n);

    curr->right=makeTree(preorder, inorder, rootIndex+1, rightin, n);

    return curr;

}

int height(treeNode *root){
    if(root==NULL){
        return 0;
    }
    else{
        return max(height(root->left), height(root->right))+1;
    }
}

void makearr(int *arr, int l, treeNode *root, int i){
    if(i>l){
        return;
    }
    if(root==NULL){
        return;
    }
    else{
    arr[i]=root->data;
    makearr(arr, l, root->left, 2*i+1);
    makearr(arr, l, root->right, 2*i+2);
    return;}
}

int main(){
    int n;
    cin >> n;
    int preorder[n];
    int inorder[n];
    for(int i=0;i<n;i++){
        cin>>preorder[i];
    }
    for(int i=0;i<n;i++){
        cin>>inorder[i];
    }
    treeNode *root=makeTree(preorder, inorder, 0, n-1, n);
    int h= height(root);
    int l=pow(2, h)-1;
    int arr[l];
    for(int i=0;i<l;i++){
        arr[i]=-1;
    }
    makearr(arr, l, root, 0);
    for(int i=0;i<l;i++){
        cout<<arr[i]<<" ";
    }
}

