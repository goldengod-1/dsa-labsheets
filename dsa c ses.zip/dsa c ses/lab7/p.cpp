#include <iostream>
using namespace std;

int main() {
	int t;
	cin >> t;
	for(int i=0;i<t;i++){
	    int a;
	    int b;
	    int c;
	    cin >> a;
	    cin >> b;
	    cin >> c;
        int arr[5];
        arr[0]=a^b^c;
        arr[1]=a^b;
        arr[2]=b^c;
        arr[3]=c^a;
        arr[4]=a;
        int d=0;
        for(int i=0;i<5;i++){
            if((arr[i]^a<arr[i]^b)&&(arr[i]^b<arr[i]^c)){
                cout << arr[i] << endl;
                d++;
            }
            if(d){
                break;
            }
        }
        if(!d){
            cout << "-1" << endl;
        }
	}
	return 0;
}
