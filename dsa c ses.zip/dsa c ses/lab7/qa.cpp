#include<iostream>
#include<queue>
using namespace std;

int main(){
    int n;
    int k;
    cin >> n;
    cin >> k;
    priority_queue<int> pq;
    for(int i=0;i<n;i++){
        int x;
        cin>>x;
        pq.push(x);
    }
    for(int i=0;i<k;i++){
        int x;
        x=pq.top();
        pq.pop();
        x=x/2;
        pq.push(x);
    }
    int sum=0;
    while(!pq.empty()){
        sum+=pq.top();
        pq.pop();
    }
    cout<<sum<<' ';
}