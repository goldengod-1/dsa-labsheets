#include<iostream>
#include<vector>
using namespace std;

class treeNode{
    public:
    int data;
    treeNode *left;
    treeNode *right;

    treeNode(int val){
        this->data=val;
        this->left=NULL;
        this->right=NULL;
    }
};

treeNode *makeTree(treeNode* curr, int *arr, int n, int i){
    if(i>=n){
        return curr;
    }
    if(i<n && arr[i]!=-1){
    curr = new treeNode(arr[i]);
    curr->left=makeTree(curr->left, arr, n, 2*i+1);
    curr->right=makeTree(curr->right, arr, n, 2*i+2);}
    return curr;
}

int path(treeNode *root, int *arr, int x, int i){
    if(root==NULL){
        return 0;
    }
    arr[i]=root->data;
    if(root->data==x){
        return 1;
    }
    if (path(root->left, arr, x, i+1) || path(root->right, arr, x, i+1))
    {
        return 1;
    }
    return 0;
}

void check(int *arr1, int *arr2, int n){
    int i=0;
    int ans;
    while(arr1[i]==arr2[i]&&i<n-1&&arr1[i]!=-1){
        ans=arr1[i];
        i++;
    }
    cout<<ans<<endl;
}

int main(){
    int n;
    int a;
    int b;
    cin >> n >> a >> b;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    treeNode *root = NULL;
    root = makeTree(root, arr, n, 0);
    int arr1[n];
    int arr2[n];
    for(int i=0;i<n;i++){
        arr1[i]=-1;
        arr2[i]=-1;
    }
    path(root, arr1, a, 0);
    path(root, arr2, b, 0);
    check(arr1, arr2, n);
}