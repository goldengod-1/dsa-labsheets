#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

typedef struct Node{
    int data;
    struct Node *next;
    struct Node *prev;
}Node;

Node *createNode(int val){
    Node *newNode=malloc(sizeof(Node));
    assert(newNode!=NULL);
    newNode->data=val;
    newNode->next=NULL;
    newNode->prev=NULL;
    return newNode;
}

Node *addToList(Node *head,int val){
    Node *newNode=createNode(val);
    Node *curr=head;
    if(head==NULL){
        return newNode;
    }
    else{
        while(curr->next!=NULL){
            curr=curr->next;
        }
        curr->next=newNode;
        newNode->prev=curr;
        return newNode;
    }
}

Node *readList(){
    int n;
    scanf("%d",&n);
    Node *head=NULL;
    for(int i=0;i<n;i++){
        int y;
        scanf("%d",&y);
        if(head==NULL){
            head=addToList(head,y);
        }
        else{
            addToList(head,y);
        }
    }
    return head;
}

void printList(Node *head){
    Node *curr=head;
    while(curr!=NULL){
        printf("%d ",curr->data);
        curr=curr->next;
    }
}

void divideTeams(Node *head,int *left,int *right){
    Node *curr1=head;
    Node *curr2=head;
    while(curr2->next!=NULL){
        curr2=curr2->next;
    }
    int lv=curr1->data;
    int rv=curr2->data;
    int lv_max=0,rv_max=0;
    (*left)+=1;
    (*right)+=1;
    while(curr1!=curr2 && curr2->next!=curr1){
        if(lv==rv){
            if ((*left)>lv_max){
                lv_max=(*left);
            }
            if ((*right)>rv_max){
                rv_max=(*right);
            }
            curr2=curr2->prev;
            rv+=curr2->data;
            (*right)+=1;
            curr1=curr1->next;
            lv+=curr1->data;
            (*left)+=1;
        }
        else if(lv>rv){
            curr2=curr2->prev;
            rv+=curr2->data;
            (*right)+=1;
        }
        else if(rv>lv){
            curr1=curr1->next;
            lv+=curr1->data;
            (*left)+=1;
        }
    }
    (*left)=lv_max;
    (*right)=rv_max;
}

void main(){
    Node *head=readList();
    int left=0,right=0;
    divideTeams(head,&left,&right);
    printf("%d %d",left,right);
}