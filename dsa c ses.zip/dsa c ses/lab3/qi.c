#include <stdio.h>
#include <stdlib.h>

long binarySearch(long l,long r,long x,long n){
    if(r>=l){
        long m=(l+r)/2;
        if((n*m-(m*(m+1)/2))>=x && (n*(m-1)-(m*(m-1)/2)<=x)){
            return m;
        }
        else if((n*m-(m*(m+1)/2))<x){
            return binarySearch(m+1,r,x,n);
        }
        else{
            return binarySearch(l,m-1,x,n);
        }
    }
}

void main(){
    long n;
    scanf("%ld",&n);
    long x=(n*(n-1))/4;
    printf("%ld",binarySearch(1,n,x,n));
}