#include <stdio.h>
#include <stdlib.h>

int maxElement(int *arr,int n){
    int max=0;
    for (int i=0;i<n;i++){
        if(max<arr[i]){
            max=arr[i];
        }
    }
    return max;
}

int checkLength(int *arr,int n,int r){
    int count=0;
    if(r==0){
        printf("0");
        exit(0);
    }
    for(int i=0;i<n;i++){
        count+=(int)(arr[i]/r);
    }
    return count;
}

int binarySearch(int* arr,int l,int r,int k,int n,int *max){
    if(r>=l){
        int m=(l+r)/2;
        if(checkLength(arr,n,m)==k){
            if((*max)<m){
                (*max)=m;
            }
            binarySearch(arr,m+1,r,k,n,max);
        }
        else if(checkLength(arr,n,m)>k){
            return binarySearch(arr,m+1,r,k,n,max);
        }
        else{
            return binarySearch(arr,l,m-1,k,n,max);
        }
    }
}

void main(){
    int n,k;
    scanf("%d",&n);
    scanf("%d",&k);
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    int max=maxElement(arr,n);
    int m=0;
    binarySearch(arr,0,max,k,n,&m);
    printf("%d",m);
}