#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

typedef struct Node{
    int data;
    struct Node *next;
    struct Node *prev;
}Node;

Node *createNode(int val){
    Node *newNode=malloc(sizeof(Node));
    assert(newNode!=NULL);
    newNode->data=val;
    newNode->next=NULL;
    newNode->prev=NULL;
    return newNode;
}

Node *addToList(Node *head,int val){
    Node *newNode=createNode(val);
    Node *curr=head;
    if(head==NULL){
        return newNode;
    }
    else{
        while(curr->next!=NULL){
            curr=curr->next;
        }
        curr->next=newNode;
        newNode->prev=curr;
        return newNode;
    }
}

Node *readList(int n){
    Node *head=NULL;
    for(int i=0;i<n;i++){
        int y;
        scanf("%d",&y);
        if(head==NULL){
            head=addToList(head,y);
        }
        else{
            addToList(head,y);
        }
    }
    return head;
}

void printList(Node *head){
    Node *curr=head;
    while(curr!=NULL){
        printf("%d ",curr->data);
        curr=curr->next;
    }
}

void rotateList(Node **head,int k){
    for(int i=0;i<k;i++){
        Node *temp=*head;
        while(temp->next!=NULL){
            temp=temp->next;
        }
        temp->next=*head;
        temp->prev->next=NULL;
        temp->prev=NULL;
        (*head)->prev=temp;
        (*head)=temp;
    }
}

void main(){
    int n,k;
    scanf("%d",&n);
    scanf("%d",&k);
    Node *head=readList(n);
    rotateList(&head,k);
    printList(head);
}

