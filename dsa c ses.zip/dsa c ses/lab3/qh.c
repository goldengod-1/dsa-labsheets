#include <stdio.h>
#include <stdlib.h>

long binarySearch(long l,long r,long x){
    if(r>=l){
        long m=(r+l)/2;
        if(m*m<=x && (m+1)*(m+1)>x){
            return m;
        }
        else if(m*m>x){
            return binarySearch(l,m-1,x);
        }
        else{
            return binarySearch(m+1,r,x);
        }
    }
}

void main(){
    long n;
    scanf("%ld",&n);
    printf("%ld",binarySearch(1,(n/2)+1,n));
}