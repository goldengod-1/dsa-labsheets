#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

typedef struct Node{
    int data;
    struct Node *next;
    struct Node *prev;
}Node;

Node *createNode(int val){
    Node *newNode=malloc(sizeof(Node));
    assert(newNode!=NULL);
    newNode->data=val;
    newNode->next=NULL;
    newNode->prev=NULL;
    return newNode;
}

Node *addToList(Node *head,int val){
    Node *newNode=createNode(val);
    Node *curr=head;
    if(head==NULL){
        return newNode;
    }
    else{
        while(curr->next!=NULL){
            curr=curr->next;
        }
        curr->next=newNode;
        newNode->prev=curr;
        return newNode;
    }
}

Node *readList(){
    int n;
    scanf("%d",&n);
    Node *head=NULL;
    for(int i=0;i<n;i++){
        int y;
        scanf("%d",&y);
        if(head==NULL){
            head=addToList(head,y);
        }
        else{
            addToList(head,y);
        }
    }
    return head;
}

void printList(Node *head){
    Node *curr=head;
    while(curr!=NULL){
        printf("%d ",curr->data);
        curr=curr->next;
    }
}


Node *incrementCurr(Node *curr){
    curr=curr->next;
    return curr;
}

Node *decrementCurr(Node *curr){
    curr=curr->prev;
    return curr;
}


void terminateProg(){
    exit(0);
}

int ifExists(Node *head,int val){
    Node *curr=head;
    while(curr!=NULL){
        if (curr->data==val){
            return 1;
        }
        curr=curr->next;
    }
    return 0;
}

Node *addAndPlay(Node** head,Node *curr){
    int y;
    scanf("%d",&y);
    if(ifExists(*head,y)){
        Node* temp=*head;
        while(temp->data!=y){
            temp=temp->next;
        }
        if(temp==*head){
            if(curr->next!=NULL){
                *head=(*head)->next;
                (*head)->prev=NULL;
                temp->next=curr->next;
                curr->next->prev=temp;
                temp->prev=curr;
                curr->next=temp;
            }
            else{
                *head=(*head)->next;
                temp->next->prev=NULL;
                temp->next=curr->next;
                temp->prev=curr;
                curr->next=temp;
            }
        }
        else if(temp->next==NULL){
            if(curr->next!=NULL){
                temp->prev->next=NULL;
                temp->next=curr->next;
                curr->next->prev=temp;
                temp->prev=curr;
                curr->next=temp; 
            }
            else{
                curr=curr->prev;
            }
        }
        else{
            if(curr->next!=NULL){
                temp->prev->next=temp->next;
                temp->next->prev=temp->prev;
                temp->next=curr->next;
                curr->next->prev=temp;
                temp->prev=curr;
                curr->next=temp;
            }
            else{
                temp->prev->next=temp->next;
                temp->next->prev=temp->prev;
                temp->next=NULL;
                temp->prev=curr;
                curr->next=temp;
            }
        }
    }
    else{
        Node *temp=createNode(y);
        if(curr->next!=NULL){
        temp->next=curr->next;
        curr->next=temp;
        temp->prev=curr;
        temp->next->prev=temp;
        }
        else{
            temp->next=NULL;
            curr->next=temp;
            temp->prev=curr;
        }
    }
    
    curr=incrementCurr(curr);
    return curr;
}

void main(){
    Node *head=readList();
    Node *curr=head;
    while(1>0){
        int m=0;
        scanf("%d",&m);
        if(m==1){
            int x;
            scanf("%d",&x);
            addToList(head,x);
        }
        else if(m==2){
            printf("%d\n",curr->data);
        }
        else if(m==3){
            if(curr->next!=NULL){
                curr=incrementCurr(curr);
            }
        }
        else if(m==4){
            if(curr->prev!=NULL){
                curr=decrementCurr(curr);
            }
        }
        else if(m==5){
            printList(head);
            terminateProg();
        }
        else if(m==6){
            curr=addAndPlay(&head,curr);
        }
    }
}