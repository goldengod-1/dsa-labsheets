#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

typedef struct Node{
    int data;
    struct Node *next;
    struct Node *prev;
}Node;

Node *createNode(int val){
    Node *newNode=malloc(sizeof(Node));
    assert(newNode!=NULL);
    newNode->data=val;
    newNode->next=NULL;
    newNode->prev=NULL;
    return newNode;
}

Node *addToList(Node *head,int val){
    Node *newNode=createNode(val);
    Node *curr=head;
    if(head==NULL){
        return newNode;
    }
    else{
        while(curr->next!=NULL){
            curr=curr->next;
        }
        curr->next=newNode;
        newNode->prev=curr;
        return newNode;
    }
}

Node *readList(){
    int n;
    scanf("%d",&n);
    Node *head=NULL;
    for(int i=0;i<n;i++){
        int y;
        scanf("%d",&y);
        if(head==NULL){
            head=addToList(head,y);
        }
        else{
            addToList(head,y);
        }
    }
    return head;
}

void printList(Node *head){
    Node *curr=head;
    while(curr!=NULL){
        printf("%d ",curr->data);
        curr=curr->next;
    }
}

int dyadAgg(Node *head,int x){
    Node* ptr1=head;
    Node* ptr2=ptr1;
    while(ptr2->next!=NULL){
        ptr2=ptr2->next;
    }
    while(ptr1!=ptr2 && ptr2->next!=ptr1){
        if(ptr1->data+ptr2->data==x){
            return 1;
        }
        else if(ptr1->data+ptr2->data>x){
            ptr2=ptr2->prev;
        }
        else{
            ptr1=ptr1->next;
        }
    }
    return 0;
}

void main(){
    int x;
    scanf("%d",&x);
    Node *head=readList();
    int y=dyadAgg(head,x);
    printf("%d",y);
}