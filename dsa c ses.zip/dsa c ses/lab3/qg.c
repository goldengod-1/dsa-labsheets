#include <stdio.h>
#include <stdlib.h>

int binarySearch(int *array,int l,int r,int x){
    if(r>=l){
        int m=(r+l)/2;
        if(array[m]<x && array[m+1]>x){
            return m;
        }
        else if(array[m]>x){
            return binarySearch(array,l,m-1,x);
        }
        else{
            return binarySearch(array,m+1,r,x);
        }
    }
}

void main(){
    int n;
    scanf("%d",&n);
    int x;
    scanf("%d",&x);
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    if(arr[n-1]<x){
        printf("%d",arr[n-1]);
        exit(0);
    }
    printf("%d",arr[binarySearch(arr,0,n-1,x)]);
}