#include <stdio.h>
int checkPrime(int a){
    int b = 0;
    for (int i = 2; i <= a/2; i++){
        if(a % i == 0 ){
            b++;
        }
    }
    if(b==0){
        return 1;
    }
    else return 0;
}


int main(){
    int a, b, maxf, maxi;
    maxf = 0; 
    maxi = 0;
    int B[10] = {0,0,0,0,0,0,0,0,0,0};
    scanf("%d %d", &a, &b);
    int n = b - a + 1;
    int A[n];
    int c = 0;
    for(int i = 0; i < n; i++){
        A[i] = 0;
    }
    for (int i = a; i <= b; i++){
        if(checkPrime(i)){
            A[c] = i;
            c++;
        }
    }
    for (int i = 0; i < c; i++){
        while(A[i] != 0){
            B[A[i]%10]++;
            A[i] = A[i]/10;
        }
    }
    for(int i = 0; i < 10; i++){
        if(B[i] > maxf){
            maxf = B[i];
            maxi = i;
        }
    }
    printf("%d %d", maxi, maxf);
}