#include <stdio.h>
int main(){
    int n;
    int temp;
    scanf("%d", &n);
    int A[n];
    for (int i = 0; i < n; i++){
        scanf("%d", &A[i]);
    }
   int i = 0, j = 0;
    while (j < n) {
        if (A[j] >= 0) {
            j++;
        }
        else {
            for (int k = j; k > i; k--) {
                int temp = A[k];
                A[k] = A[k - 1];
                A[k - 1] = temp;
            }
            i++;
            j++;
        }
    }
    for(int i = 0; i < n; i++){
        printf("%d ", A[i]);
    }
}
 

