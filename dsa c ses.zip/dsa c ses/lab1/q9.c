#include <stdio.h>
int main(){
    int n;
    int k;
    int temp;
    scanf("%d", &k);
    int mid = (k+1)/2;
    scanf("%d", &n);
    int A[n];
    for (int i = 0; i < n; i++){
        scanf("%d", &A[i]);
    }
   int i = 0, j = 0;
    while (j < n) {
        if (A[j] >= mid) {
            j++;
        }
        else {
            for (int k = j; k > i; k--) {
                int temp = A[k];
                A[k] = A[k - 1];
                A[k - 1] = temp;
            }
            i++;
            j++;
        }
    }
    for(int i = 0; i < n; i++){
        printf("%d ", A[i]);
    }
}
 

