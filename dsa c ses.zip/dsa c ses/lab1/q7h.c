#include <stdio.h>
#include <string.h>

int main(){
    char sentence[1000];
    char input[1000];
    fgets(sentence, 1000, stdin);
    fgets(input, 1000, stdin);
    int initialwindow = strlen(input);
    int initialstart = 0;
    int initialend = initialwindow;
    int minWindowSize = 1000;
    int minStart = 0;
    int minEnd = 0;
    int inputAlphabetArray[26];
    for (int i = 0; i < 26; i++)
    {
        inputAlphabetArray[i] = 0;
    }
 
    for (int i = 0; i < initialWindowSize; i++)
    {
        inputAlphabetArray[input[i] - 'a']++;
    }
    while (initiialend < strlength(sentence)){
        int windowalphabetarray[26];
        for(int i = 0; i < 26; i++){
            windowalphabetarray[i] = 0;
        }
        for (i = intialstart; i < initialend; i++){
            if(inputAlphabetArray[sentence[i] - 'a'] != -1){
                windowalphabetarray[sentence[i] - 'a']++; 
            }
        }
        int matches = 1;
        int toshiftstart = 0;
        int toshiftend = 0;
        for(int i = 0; i < 26; i++){
            if(windowalphabetarray[i] > inputAlphabetArray[i]){
                matches = 0;
                initialend++;
            }
        }
        if(matches){
            if(initialend - initialstart < minWindowSize){
                
            }
        }
    }
}