#include <stdio.h>

int main() {
    int n;
    scanf("%d",&n);

    int a=2*n-1;
    int arr[a][a];
    for (int i =0; i < a; i++)
    {
       for(int j=0;j<a;j++)
       {
        arr[i][j]=-5;
       }
    }
    int f= 2*n*n;
    int top=0,left=0,right=a-1,bottom=a-1;

    while(top<=bottom && left<=right && f>=0)
    {

    for(int i=right;i>=left;i-=2 )
{
    arr[bottom][i]=f;
    f-=2;
}  bottom-=2;

    for(int i=bottom;i>=top;i-=2)
{
        arr[i][left]=f;
        f-=2;
} left+=2;

    for(int i=left;i<=right;i+=2)
    {
        arr[top][i]=f;
        f-=2;
    } top+=2;

    for(int i =top;i<=bottom;i+=2)
    {
        arr[i][right]=f;
        f-=2;
    } right-=2;
    }
for(int i=0;i<a;i++)
{
    for(int j=0;j<a;j++)
    {   
        if(i%2==0 && j%2==0)
    {
        if((arr[i][j]-arr[i][j+2]==2) || (arr[i][j]-arr[i][j+2]==-2) )
        {
            arr[i][j+1]=-1;
        }
    //     else
    //    { 
    //     arr[i][j+1]=0;
    //    }
    
    }
        if(i%2==0 && j%2==0)
        {
            if((arr[i][j]-arr[i+2][j]==2) || (arr[i][j]-arr[i+2][j]==-2))
        {
            arr[i+1][j]=-2;
        }
        // else
        // { 
        //    arr[i+1][j]=0;  
        // }
        }
    }
}
    for(int i=0;i<a;i++)
    {
        for(int j=0;j<a;j++)
        {
            if(i%2==0 && j%2==0)
            {
                printf("%3d",arr[i][j]);
            }
            
           if(arr[i][j]==-1)
           {
            printf(" - ");
           }
           if(arr[i][j]==-2)
           {
            printf(" | ");
           }
           if(arr[i][j]==-5)
           {
            printf("   ");
           }
     
        }
        printf("\n");
    }

    


    return 0;
}