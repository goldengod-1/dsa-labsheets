#include <stdio.h>
#include <string.h>
void reverse(char* begin, char* end)
{
    char temp;
    while (begin < end) {
        temp = *begin;
        *begin++ = *end;
        *end-- = temp;
    }
}

void reverseWords(char* s)
{
    char* word_begin = s;
 
    // Word boundary
    char* temp = s;
 
    // Reversing individual words as
    while (*temp) {
        temp++;
        if (*temp == '\0') {
            reverse(word_begin, temp - 1);
        }
        else if (*temp == ' ') {
            reverse(word_begin, temp - 1);
            word_begin = temp + 1;
        }
    }
}


int main(){
    char sentence[1000];
    char buffer[1000];
    for(int i = 0; i < 1000; i++){
        sentence[i] = '\0';
        buffer[i] = '\0';
    }
    scanf("%[^\n]", sentence);
    strcpy(buffer, sentence);
    reverseWords(buffer);
    int i, j, m;
    i = 0; j = 0;
    while(sentence[i]){
        m = 1;
        i++;
        if(sentence[i] == '\0'){
            for(int k = j; k < i; k++){
                if(sentence[k] != buffer[k]){
                    m = 0;
                }
            }
            if(m){
                for(int k = j; k < i; k++){
                    printf("%c", sentence[k]);
                }
            }
        }
        else if(sentence[i] == ' '){
            for(int k = j; k < i; k++){
                if(sentence[k] != buffer[k]){
                    m = 0;
                }
            }
            if(m){
                for(int k = j; k < i; k++){
                    printf("%c", sentence[k]);
                }
                printf(" ");
            }
            j = i + 1;
        }
        
    }


}
