#include <stdio.h>

void check(char *arr1, char *arr2){
    int n1, n2;
    n1 = 0; 
    n2 = 0; 
    while(arr1[n1]!='\0'){
        n1++;
    }
    while(arr2[n2]!='\0'){
        n2++;
    }
    if(n1 != n2){
        printf(" NOT POSSIBLE");
        return;
    }
    int arr1l[26];
    int arr2l[26];
    for (int i = 0; i < 26; i++){
        arr1l[i] = 0;
        arr2l[i] = 0;
    }
    for (int i = 0; i <= n1; i++){
        arr1l[(int)arr1[i] - 97]++;
    }
    for (int i = 0; i <= n2; i++){
        arr2l[(int)arr2[i] - 97]++;
    }
    for(int i = 0; i < 26; i++){
        if(!(arr1l[i] == arr2l[i])){
            printf("NOT POSSIBLE");
            return;
        }
    }
    printf("YES %d %d\n", n1, n2);
    for (int i = 0; i < n2; i++){
        for(int j = 0; j < n1; j++){
           if(arr2[i] == arr1[j]){
            printf("%d", j+1);
           } 
        }
    }

}

int main(){

    char arr1[1000];
    char arr2[1000];
    scanf("%s", arr1);
    scanf("%s", arr2);
    check(arr1, arr2);
}
