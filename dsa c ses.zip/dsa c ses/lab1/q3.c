// A recursive solution for subset sum problem
#include <stdio.h>

void print_array(int* arr, int size) {
	for(int i = 0; i < size; i++) {
		printf("%d ", arr[i]);
	}
	printf("\n");
}
// Returns true if there is a subset
// of set[] with sum equal to given sum
int isSubsetSum(int arr[], int set[], int n, int sum)
{
	printf("Arr : ");
	print_array(arr, 5);
	printf("Set : ");
	print_array(set, 5);
	// Base Cases
	if (sum == 0)
		return 1;
	if (n == 0)
		return 0;

	// If last element is greater than sum,
	// then ignore it
	if (set[n - 1] > sum){
		arr[n] = 0;
		return isSubsetSum(arr, set, n - 1, sum);
	}

	/* else, check if sum can be obtained by any
of the following:
	(a) including the last element
	(b) excluding the last element */
	return isSubsetSum(arr, set, n - 1, sum)
		|| isSubsetSum(arr, set, n - 1, sum - set[n - 1]);
}


// int subsetSum(int* set, int*arr, int n, int sum, int x){
// 	if(n == 0){
// 		if(sum == 0){
// 			return 1;
// 		}
// 		return 0;
// 	}
// 	if(x == 0){
// 		if(set[x] == sum){
// 			arr[x] = 1;
// 			return 1;
// 		}
// 		arr[x] = 0;
// 		return 0;
// 	}
// 	// exclude
// 	int exclude = subsetSum(set,arr,n,sum,x-1);
// 	if(exclude){
// 		return 1;
// 	}
// 	// include
// 	arr[x] = 1;
// 	int include = subsetSum(set,arr,n,sum-set[x],x-1);
// 	if(include){
// 		return 1;
// 	}
// 	arr[x] = 0;
// 	return 0;
// }



int subsetSum(int* set, int*arr, int n, int sum, int x){
	if(n == 0){
		if(sum == 0){
			return 1;
		}
		return 0;
	}
	if(x == 0){
		if(set[x] == sum){
			arr[x] = 1;
			return 1;
		}
		arr[x] = 0;
		return 0;
	}
	// exclude
	int exclude = subsetSum(set,arr,n,sum,x-1);
	if(exclude){
		return 1;
	}
	// include
	arr[x] = 1;
	int include = subsetSum(set,arr,n,sum-set[x],x-1);
	if(include){
		return 1;
	}
	arr[x] = 0;
	return 0;
}


// Driver code
int main()
{
	int set[] = { 6, 4, 7, 4, 9};
	int arr[] = {0, 0, 0, 0, 0}; // initial state when nothing is included
	int sum = 23;
	int n = sizeof(set) / sizeof(set[0]);
	printf("n : %d\n", n);
	// if (subsetSum(arr, set, n, sum) == 1){
	// 	printf("Found a subset with given sum");
	// 	for(int i = 0; i < n; i++){
	// 		if(arr[i]){
	// 			printf("%d ", i);
	// 		}
	// 	}}
	// else
	// 	printf("No subset with given sum")

	int x =n-1;
	int ans = subsetSum(set,arr,n,sum,x);
	printf("%d\n",ans);
	print_array(arr,n);



	return 0;
}
