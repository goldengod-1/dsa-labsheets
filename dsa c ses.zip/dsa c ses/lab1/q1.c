#include <stdio.h>

int main() {
    int m, n;
    scanf("%d %d", &m, &n);
    int A[m][n];
    int B[m][n];
    int c = 0;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
        scanf("%d", &A[i][j]);
        c += A[i][j];
        B[i][j] = c;
        }
    }

   
    int ri, ci, rh, ch;
    scanf("%d %d %d %d", &ri, &ci, &rh, &ch);
    if (ri + rh > m || ci + ch > n) {
        printf("Cannot create a sub-matrix of size rh x ch from B[ri][ci]\n");
        return 0;
    }

    int submatrixsum = 0;
    for (int i = ri; i < ri + rh; i++) {
        for (int j = ci; j < ci + ch; j++) {
            submatrixsum+=B[i][j];
        }
    }


    printf("Sub-matrix of B starting at B[%d][%d] and of size %d x %d:\n", ri, ci, rh, ch);

    for (int i = ri; i < ri + rh; i++) {
        for (int j = ci; j < ci + ch; j++) {
            printf("%d ", B[i][j]);
        }
        printf("\n");
    }

    printf("Sum of elements in the sub-matrix: %d\n", submatrixsum);

    return 0;
}