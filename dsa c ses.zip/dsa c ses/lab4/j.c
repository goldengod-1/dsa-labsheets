#include <stdio.h>
#include<limits.h>

int findMax(int *arr, int n){
    long long int m = arr[0];
    for(int i = 0; i < n; i++){
        if(arr[i] > m){
            m = arr[i];
        }
    }
    return m;
}

void equalchocolates(int *arr, int n){
    int c=findMax(arr, n);
    long long int min=INT_MAX;
    for(int j=c;j>=0;j--){
        int f=0;
        for(int i = 0; i < n; i++){
            if(arr[i] - j < 0){
                f-=(arr[i]-j);
            }
            else{
                f+=(arr[i]-j);
            }
        }
        if(min>f){
            min=f;
        }
    }
    printf("%d", min);
}

int main(){
    int n;
    scanf("%d", &n);
    int arr[n];
    for(int i = 0; i < n; i++){
        scanf("%d", &arr[i]);
    }
    equalchocolates(arr, n);
}