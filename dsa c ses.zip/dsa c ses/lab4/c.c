#include <stdio.h>
#include <math.h>

int findMax(int *arr, int n){
    int m = arr[0];
    for(int i = 0; i < n; i++){
        if(arr[i] > m){
            m = arr[i];
        }
    }
    return m;
}
int findZero(int n){
    int c=0;
    while(n!=0){
        c=c+n/5;
        n=n/5;
    }
    return c;
}
int nc2(int n){
    return n*(n-1)/2;
}

void countPairs(int *arr, int n){
    int max = findMax(arr, n);
    int c=0;
    int ans=0;
    while(max!=0){
        c=c+max/5;
        max=max/5;
    }
    int z[c+1];
    for(int i=0;i<=c;i++){
        z[i]=0;
    }
    for(int i=0;i<n;i++){
        z[findZero(arr[i])]++;
    }
    for(int i=0;i<=c;i++){
        ans=ans+nc2(z[i]);
    }
    printf("%d", ans);
}
int main(){
    int n;
    scanf("%d", &n);
    int arr[n];
    for(int i = 0; i < n; i++){
        scanf("%d", &arr[i]);
    }
    countPairs(arr, n);
}