#include <stdio.h>
#include <math.h>


int seive(int n){
    int p[n+1];
    int count=0;
    for(int i=0;i<n+1;i++){
        p[i]=1;
    }
    for(int j=2;j*j<=n;j++){
        if(p[j]==1){
            for(int i=j*j;i<=n;i+=j){
                p[i]=0;
            }
        }
    }
    for(int i=2;i<n+1;i++){
        count+=p[i];
    }
    return count;
}

int main(){
    int n, k;
    scanf("%d %d", &n, &k);
    int arr[k];
    for(int i = 0; i < k; i++){
        scanf("%d", &arr[i]);
    }
    for(int i=0;i<k;i++){
        printf("%d ", seive(arr[i]));
    }
}
