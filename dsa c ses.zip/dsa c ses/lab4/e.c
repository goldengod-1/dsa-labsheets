#include<stdio.h>
#include<math.h>

int gcd(int a, int b){
    if(a == 0){
        return b;
    }
    if(b == 0){
        return a;
    }
    else{
       return gcd(b, a%b);
    }

}

void findans(int a, int b){
    while(gcd(a,b)!=1){
        a/=gcd(a, b);
    }
    printf("%d", a);
}

int main(){
    int a, b;
    scanf("%d %d", &a, &b);
    findans(a, b);
}
