#include <stdio.h>
#include <math.h>

int check(int *arr, int n, int k){
    int c = 0;
    for(int i = 0; i < n; i++){
        if(arr[i] >= k){
            c++;
        }
    }
    if(c == k){
        return 2;
    }
    else if(c > k){
        return 1;
    }
    return 0;
}

int bin(int *arr, int n){
    int l, m, r;
    r = n;
    l = 1;
    int q=0;
    if(check(arr, n, n)==2){
        return n;
    }
    while(l < r){
        m = (l+r)/2;
        int x = check(arr, n, m);
        if(x == 1){
            l = m + 1;
        }
        else if(x == 0){
            r = m;
        }
        else{
            q = m;
            l = m+1;
        }
    }
    return q;
}

int main(){
    int n;
    scanf("%d", &n);
    int arr[n];
    for(int i = 0; i < n; i++){
        scanf("%d", &arr[i]);
    }
    int ans = bin(arr, n);
    printf("%d", ans);
}