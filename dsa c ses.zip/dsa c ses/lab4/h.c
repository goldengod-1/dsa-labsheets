#include<stdio.h>

void allies(int k, int r){
    int max = (k-r+1)*(k-r)/2;
    int min;
    int x = k/r;
    int y = k%r;
    min = y*(x+1)*(x)/2 + (r-y)*(x)*(x-1)/2;
    printf("%d %d", min, max);
}

int main(){
    int k;
    int r;
    scanf("%d %d", &k, &r);
    allies(k, r);
}