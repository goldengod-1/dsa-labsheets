#include<stdio.h>
#include<stdlib.h>

typedef struct time{
    int start;
    int end;
}time;

void sortedMerge(time *arr, int l, int r, int m){
    time left[m-l+1], right[r-m];
    for(int i=0;i<m-l+1;i++){
        left[i]=arr[i+l];
    }
    for(int i=0;i<r-m;i++){
        right[i]=arr[m+i+1];
    }
    int i=0,j=0;
    while(i<m-l+1&&j<r-m){
        if(left[i].start>right[j].start){
            arr[i+j+l]=right[j];
            j++;
        }
        else if(left[i].start==right[j].start){
            if(left[i].end>right[j].end){
                arr[i+j+l]=right[j];
                j++;
            }
            else{
                arr[i+j+l]=left[i];
                i++;
            }
        }
        else{
            arr[i+j+l]=left[i];
            i++;
        }
    }
    while(i<m-l+1){
        arr[i+j+l]=left[i];
        i++;
    }
    while(j<r-m){
        arr[i+j+l]=right[j];
        j++;
    }
}

void mergeSort(time *arr, int l, int r){
    if(l<r){
        int m=(l+r)/2;
        mergeSort(arr, l, m);
        mergeSort(arr, m+1, r);
        sortedMerge(arr, l, r, m);
    }
}

time *shiftArr(time *arr, int n, int i, int count){
    for(int j=i;j<n-1;j++){
        arr[j]=arr[j+1];
    }
    arr = (time *)realloc(arr, count*sizeof(time));
    return arr;
}

int main(){
    int n;
    scanf("%d", &n);
    time *arr;
    arr = (time *)malloc(n*sizeof(time));
    for(int i=0;i<n;i++){
        scanf("%d", &arr[i].start);
        scanf("%d", &arr[i].end);
    }
    mergeSort(arr, 0, n-1);
    int count=n;
    int i=0;
    while(i<count-1){
        if(arr[i].start==arr[i+1].start){
            arr[i].end=arr[i+1].end;
            count--;
            shiftArr(arr, n, i+1, count);
            continue;
        }
        else if(arr[i+1].start<=arr[i].end){
            if(arr[i].end>arr[i+1].end){
                count--;
                shiftArr(arr, n, i+1, count);
            }
            else{
                arr[i].end=arr[i+1].end;
                count--;
                shiftArr(arr, n, i+1, count);
            }
            continue;
        }
        i++;
    }
    printf("%d\n", count);
    for(int i=0;i<count;i++){
        printf("%d %d\n", arr[i].start, arr[i].end);
    }
}