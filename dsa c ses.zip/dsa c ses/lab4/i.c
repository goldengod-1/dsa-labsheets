#include<stdio.h>

int gcd(int a, int b){
    if(a == 0){
        return b;
    }
    else if(b == 0){
        return a;
    }
    else{
        return gcd(b, a%b);
    }
}

void findmaxgcd(int *arr, int n){
    int max = 1;
    for(int j = 0; j < n; j++){
        int a = 0;
        for(int i = 0; i < n; i++){
            if(j == i){
                a = gcd(a, 0);
            }
            else{
                a = gcd(a, arr[i]);
            }
        }
        if(a>max){
            max = a;
        }
    }
    printf("%d", max);
}

int main(){
    int n;
    scanf("%d", &n);
    int arr[n];
    for(int i = 0; i < n; i++){
        scanf("%d", &arr[i]);
    }
    findmaxgcd(arr, n);
}