#include <stdio.h>
#include <math.h>


int findMax(int *arr, int n){
    int m = arr[0];
    for(int i = 0; i < n; i++){
        if(arr[i] > m){
            m = arr[i];
        }
    }
    return m;
}


void bonVoyage(int *arr, int n, int k){
    int x=findMax(arr,n);
    int can[x+1];
    for(int i=0;i<=x;i++){
        can[i]=0;
    }
    for(int i=0;i<n;i++){
        can[arr[i]]++;
    }
    int klist[k];
    for(int j=0;j<k;j++){
        int m = can[0];
        int index=0;
        for(int i=0;i<=x;i++){
            if(can[i] > m){
                m = can[i];
                index=i;
            }
        }
        can[index]=-1;
        klist[j]=index;
    }
    for(int i=k-1;i>=0;i--){
        printf("%d ",klist[i]);
    }

}


int main(){
    int n, k;
    scanf("%d", &n);
    scanf("%d", &k);
    int arr[n];
    for(int i = 0; i < n; i++){
        scanf("%d", &arr[i]);
    }
    bonVoyage(arr,n,k);
}