#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
struct Node_t
{
    int data;
    struct Node_t *next;
};
typedef struct Node_t Node;

Node *createNode(int value){
    Node *newNode = malloc(sizeof(Node));
    assert(newNode != NULL);
    newNode->data = value;
    newNode->next = NULL;
    return newNode;
}

Node *addToList(Node *head, int value){
    Node *newNode = createNode(value);
    if(head == NULL){
        return newNode;
    }
    Node *cur = head;
    while(cur->next != NULL){
        cur = cur->next;
    }
    cur->next = newNode;
    return newNode;
}

Node *readList(){
    int n;
    scanf("%d", &n);
    Node *head = NULL;
    for(int i = 0; i < n; i++){
        int x;
        scanf("%d", &x);
        if (head == NULL)
        {
            head = addToList(head, x);
        }
        else
        {
            addToList(head, x);
        }
    }
    return head;
}

void printList(Node *head)
{
    Node *ptr = head;
    while (ptr != NULL)
    {
        printf("%d ", ptr->data);
        ptr = ptr->next;
    }
    printf("\n");
    return;
}

void freeList(Node *head)
{
    Node *cur, *nxt;
    cur = head;
    while (cur != NULL)
    {
        nxt = cur->next;
        free(cur);
        cur = nxt;
    }
}

Node *getMid(Node *head){
    Node *slow = head;
    Node *fast = head;
    while(fast->next->next != NULL && fast->next != NULL && fast != NULL){
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}

Node *mergeList(Node *head1, Node *head2){
    Node *mergedList = NULL;
    if(head1 == NULL){
        return head2;
    }
    if(head2 == NULL){
        return head1;
    }
    else if(head1->data <= head2->data){
        mergedList = head1;
        mergedList->next = mergeList(head1->next, head2);
    }
    else{
        mergedList = head2;
        mergedList->next = mergeList(head1, head2->next);
    }
    return mergedList;
}

Node *sortList(Node *head){
    if(head == NULL){
        return head;
    }
    if(head->next == NULL){
        return head;
    }
    Node *left = head;
    Node *right = getMid(head);
    Node *temp = right->next;
    right->next = NULL;
    right = temp;
    left = sortList(left);
    right = sortList(right);
    return mergeList(left, right);
}

Node *reverseList(Node *head){
    Node *prev = NULL;
    Node *curr = head;
    while(curr != NULL){
        Node *nxt = curr->next;
        curr->next = prev;
        prev = curr;
        curr = nxt;
    }
    return prev;
}


Node *removeSlide(Node *head, int k){
    int n = 0;
    Node *ptr = head;
    while(n < n - k){
        ptr = ptr->next;
        n++;
    }
    ptr->next = ptr->next->next;
    return head;
}

Node *rearrangeList(Node *head){
    Node *ptr = head->next;
    Node *odd = head;
    Node *even = head->next;
    while(odd->next != NULL && even->next != NULL){
        odd->next = even->next;
        odd = odd->next;
        even->next = odd->next;
        even = even->next;
    }
    odd->next = ptr;
    return head;
}


int main(void)
{
    int k;
    scanf("%d", &k);
    Node *head = readList();
    Node *corrected = removeSlide(head, k);
    printList(corrected);
    // freeList(corrected);
    // freeList(head);
}