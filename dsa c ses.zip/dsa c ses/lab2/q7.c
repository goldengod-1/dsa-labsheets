#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
struct Node_t
{
    int data;
    struct Node_t *next;
};
typedef struct Node_t Node;
// Creates a new node with given value and returns a pointer to it
Node *createNode(int value)
{
    Node *newNode = malloc(sizeof(Node));
    assert(newNode != NULL);
    newNode->data = value;
    newNode->next = NULL;
    return newNode;
}
// Creates a new node with given value and adds it to
// the back of the given singly linked list,
// returns a pointer to the newly created node
Node *addToList(Node *head, int val)
{
    Node *newNode = createNode(val);
    if (head == NULL)
    {
        return newNode;
    }
    Node *cur = head;
    while (cur->next != NULL)
    {
        cur = cur->next;
    }
    cur->next = newNode;
    return newNode;
}
// Creates a singly linked list by reading input and
// returns a pointer the head of the newly created linked list
Node *readList()
{
    int n;
    scanf("%d", &n);
    Node *head = NULL;
    for (int i = 0; i < n; ++i)
    {
        int x;
        scanf("%d", &x);
        if (head == NULL)
        {
            head = addToList(head, x);
        }
        else
        {
            addToList(head, x);
        }
    }
    return head;
}
// Prints the values stored in the nodes of the given singly linked list
void printList(Node *head)
{
    Node *ptr = head;
    while (ptr != NULL)
    {
        printf("%d ", ptr->data);
        ptr = ptr->next;
    }
    printf("\n");
    return;
}
// Frees the memory dynamically allocated to
// all the nodes of the given singly linked list
void freeList(Node *head)
{
    Node *cur, *nxt;
    cur = head;
    while (cur != NULL)
    {
        nxt = cur->next;
        free(cur);
        cur = nxt;
    }
}
Node *getMid(Node *head){
    Node *slow = head;
    Node *fast = head;
    while(fast->next != NULL && fast != NULL){
        fast = fast->next->next;
        slow = slow->next;
    }
    return slow;
}
int median(Node *head){
    Node *ptr = head;
    int n = 0;
    while(ptr != NULL){
        n++;
        ptr = ptr->next;
    }
    ptr = head;
    if(n%2 == 0){
        int i = 0;
        while(i != n/2 - 1){
            ptr = ptr->next;
            i++;
        }
        return (ptr->data + ptr->next->data)/2;
    }
    else{
        int i = 0;
        while( i != (n-1)/2){
            ptr = ptr->next;
            i++;
        }
        
        return ptr->data;
    }
}
Node *mergeList(Node *head1, Node *head2){
    Node *mergedList = NULL;
    if(head1 == NULL){
        return head2;
    }
    else if(head2 == NULL){
        return head1;
    }
    else if (head1->data <= head2->data){
        mergedList = head1;
        mergedList->next = mergeList(head1->next, head2);
    }
    else {
        mergedList = head2;
        mergedList->next = mergeList(head1, head2->next);
    }
    return mergedList;

}

Node *sortList(Node *head){
    if (head == NULL){
        return head;
    }
    if (head->next == NULL){
        return head;
    }
    else{
    Node *left = NULL;
    Node *right = NULL;
    Node *temp = NULL;
    left = head;
    right = getMid(head);
    temp = right->next;
    right->next = NULL;
    right = temp;
    left = sortList(left);
    right = sortList(right);
    return mergeList(left, right);
    }
}

Node *reverseList(Node *head){
    // if (head == NULL){
    //     return head;
    // }
    // if (head->next == NULL){
    //     return head;
    // }
    // Node *rest = reverseList(head->next);
    // head->next->next = head;
    // head->next = NULL;
    // return rest;

    Node *prev = NULL;
    Node *curr = head;
    while(curr != NULL){
        Node *nxt = curr->next;
        curr->next = prev;
        prev = curr;
        curr = nxt;
    }
    return prev;
    
}

int isPalindrome(Node *head){
    Node *mid = getMid(head);
    mid = reverseList(mid->next);
    while(mid != NULL){
        if (!(mid->data == head->data)){
            return 0;
        }
        head = head->next;
        mid = mid->next;
    }
    return 1;
}

Node *rearrangeList(Node *head){
    Node *ptr = head->next;
    Node *odd = head;
    Node *even = head->next;
    while(odd->next != NULL && even->next != NULL){
        odd->next = even->next;
        odd = odd->next;
        even->next = odd->next;
        even = even->next;
    }
    odd->next = ptr;
    // even->next = NULL;
    return head;    
}

Node *removeRepeatedNodes(Node *head){
    Node * dummy = malloc(sizeof(Node));
    dummy->next=head;
    Node * prev = dummy;

    while(head != NULL)
    {
        if(head->next !=NULL && head->data==head->next->data)
        {
            while(head->next != NULL && head->data==head->next->data)
            {
                head=head->next;
            }
            prev->next=head->next;
        }
        else
        prev=prev->next;

        head=head->next;
    }
    return dummy->next;

}

Node *removeSlide(Node *head, int k){
    int n = 1;
    Node *ptr = head;
    while(n < k){
        ptr = ptr->next;
        n++;
    }
    ptr->next = ptr->next->next;
    return head;
}

int main(void)
{
    Node *head = readList();
    Node *newList = removeRepeatedNodes(head);
    printList(newList);
}