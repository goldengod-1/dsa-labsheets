#include <stdio.h>
#include <stdlib.h>
struct countries{
    char name[1000];
    int gold;
    int silver;
    int bronze;
};
typedef struct countries country;


int main(){
    int n;
    scanf("%d", &n);
    country *countrydata = (country *)malloc(n * sizeof(country));
    for (int i = 0; i < n; i++){
        scanf("%s %d %d %d", countrydata[i].name, &countrydata[i].gold, &countrydata[i].silver, &countrydata[i].bronze);
    }
    country temp;
    // for (int i = 0; i < n; i++){
    //     printf("%d", countrydata[i].bronze);
    // }
    for (int i = 0; i < n; i++){
        for(int j = 0; j < n-1; j++){
            if(countrydata[j].gold > countrydata[j+1].gold){
                temp = countrydata[j+1];
                countrydata[j+1] = countrydata[j];
                countrydata[j] = temp;
            }
            else if(countrydata[j].gold == countrydata[j+1].gold && countrydata[j].silver > countrydata[j+1].silver){
                temp = countrydata[j+1];
                countrydata[j+1] = countrydata[j];
                countrydata[j] = temp;
            }
            else if(countrydata[j].gold == countrydata[j+1].gold && countrydata[j].silver == countrydata[j+1].silver && countrydata[j].bronze > countrydata[j+1].bronze){
                temp = countrydata[j+1];
                countrydata[j+1] = countrydata[j];
                countrydata[j] = temp;
            }
        }
    }
    for (int i = n-1; i >= 0; i--){
        printf("%s\n", countrydata[i].name);
    }
}