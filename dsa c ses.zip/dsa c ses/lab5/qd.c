#include <stdio.h>

void quiz(int *arr, int n, int k, int t){
    int i=0;
    int j=k-1;
    int c=0;
    int sum=0;
    for(int x=i;x<j;x++){
        sum+=arr[x];
    }
    while(j<n){
        if(sum>=k*t){
            c++;
        }
        sum-=arr[i];
        i++;
        j++;
        sum+=arr[j];
    }
    printf("\n%d", c);
}

int main(){
    int n;
    int k;
    int t;
    scanf("%d %d %d", &n, &k, &t);
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d", &arr[i]);
    }
    quiz(arr, n, k, t);
}