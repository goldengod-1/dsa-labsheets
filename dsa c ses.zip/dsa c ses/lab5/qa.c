#include <stdio.h>


void printBrackets1(int pos, int n, int open, int close,int *ptr){
    static char str[14];
    static int count= 0;
    if(close==n){
        // count++;
        (*ptr)++;
        return;
        
    }
    else{
        if(open>close){
            str[pos]=')';
            printBrackets1(pos+1, n, open, close+1,ptr);

        }
        if(n>open){
            str[pos]='(';
            printBrackets1(pos+1, n, open+1, close,ptr);
        }
    }
    
}


void printBrackets(int pos, int n, int open, int close){
    static char str[14];
    if(close==n){
        printf("%s\n", str);
        return;
        
    }
    else{
        if(open>close){
            str[pos]=')';
            printBrackets(pos+1, n, open, close+1);

        }
        if(n>open){
            str[pos]='(';
            printBrackets(pos+1, n, open+1, close);
        }
    }
    
}

int main(){
    int n;
    scanf("%d", &n);
    int count=0;
    int *ptr=&count;
    printBrackets1(0, n/2, 0, 0, ptr);
    printf("%d\n",count);
    printBrackets(0,n/2,0,0);
}

// void printBrackets(int pos, int n, int close, int open){
//     static char str[14];
//     if(close==n){
//         printf("%d", str);
//     }
//     else{
//         if(open>close){
//             str[pos]=')';
//             printBrackets(pos+1, n, close+1, open);
//         }
//         if(open<n){
//             str[pos]='(';
//             printBrackets(pos+1, n, close, open+1);
//         }
//     }
// }