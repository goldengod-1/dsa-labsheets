#include <stdio.h>

int main()
{
    int n, k;
    scanf("%d %d", &n, &k);

    int arr[n];

    int oddCount=0;

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
        if(arr[i]%2==1)
        {
            oddCount++;
        }
    }

    int odd[oddCount];

    int j=0; 
    for(int i=0;i<n;i++)
    {
        if(arr[i]%2==1)
        {
            odd[j]=i;
            j++;
        }
    }

    int ans =0;

    for(int i=0;i<oddCount-k+1;i++){
        int j=i+k-1;
        int start=odd[i];
        int end=odd[j];

        int leftc=1;
        int rightc=1;

        if(i==0){
            leftc=odd[i]+1;
        }
        if(j==oddCount-1){
            rightc=1;
        }
        if(i!=0){
            leftc=odd[i]-odd[i-1];
        }
        if(j<oddCount-1){
            rightc=odd[j+1]-odd[j];
        }
        printf("%d %d\n", leftc, rightc);
        ans=ans + rightc*leftc;
    }

    printf("%d", ans);
}