#include <stdio.h>
int main(){
    int n;
    int m;
    int a=0;
    int b=0;
    scanf("%d", &n);
    int arr1[n];
    for(int i=0;i<n;i++){
        scanf("%d", &arr1[i]);
        a=a^arr1[i];
    }
    scanf("%d", &m);
    int arr2[m];
    for(int i=0;i<m;i++){
        scanf("%d", &arr2[i]);
        b=b^arr2[i];
    }
    if(m%2==0){
        a=0;
    }
    if(n%2==0){
        b=0;
    }
    int x=a^b;
    printf("%d", x);
    }