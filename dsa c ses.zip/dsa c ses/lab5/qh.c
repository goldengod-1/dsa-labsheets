#include <stdio.h>

void dataTrouble(int *arr, int n, int k){
    int c=0;
    for(int i=1;i<n;i++){
        arr[i]+=arr[i-1];
    }
    int freq[k];
    for(int i=0;i<n;i++){
        freq[arr[i]%k]=0;
    }
    for(int i=0;i<n;i++){
        freq[arr[i]%k]++;
    }
    c+=freq[0];
    for(int i=0;i<n;i++){
        c+=freq[arr[i]%k]*(freq[arr[i]%k]-1)/2;
        freq[arr[i]%k]=0;
    }
    printf("%d", c);
}

int main(){
    int n;
    int k;
    scanf("%d %d", &n , &k);
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d", &arr[i]);
    }
    dataTrouble(arr, n, k);
}