#include <stdio.h>
#include <stdlib.h>

int maxi(int a, int b){
    if(a>b){return a;}
    else{return b;}
}

void dynamite(int *arr, int n, int k){
    int i=0;
    int j=0;
    int c=0;
    int max=0;
    c+=(1-arr[0]);
    while(j<n){
        if(c<=k){
            j++;
            c+=(1-arr[j]);
            if(c<=k){
            max=maxi(max, j-i+1);
        }}
        else if(c>k){
            c=c-(1-arr[i]);
            i++;
        }
    }
    printf("%d", max);
}

int main(){
    int n;
    int k;
    scanf("%d %d", &n, &k);
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d", &arr[i]);
    }
    dynamite(arr, n, k);
}